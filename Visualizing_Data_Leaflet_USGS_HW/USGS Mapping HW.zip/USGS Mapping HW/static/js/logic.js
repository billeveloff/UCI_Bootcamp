
//Save USGS API endpoint as variable
var usgsUrl = "https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/all_week.geojson";

//Save github fraxen tectonic plates API endpoint as variable
//var tectonicUrl = "https://github.com/fraxen/tectonicplates/blob/master/GeoJSON/PB2002_boundaries.json";

//GET request to query USGS URL and send data.features 
//to createFeatures function
d3.json(usgsUrl, function (data) {
  createFeatures(data.features);
});


//Create function with GeoJSON overlay to identify earthquake coordinates,
//magnitude by circle size, and marker describing
//location, date & time, and magnitude
function createFeatures(earthquakeData) {

  //Variable for GeoJSON layer 
  var earthquakes = L.geoJSON(earthquakeData, {
    pointToLayer: function (feature, latlng) {
      return L.circleMarker(latlng, {
        radius: circleSize(feature.properties.mag),
        fillColor: circleColor(feature.properties.mag),
        color: "black",
        weight: 0.5,
        opacity: 0.9,
        fillOpacity: 0.6
      });
    },
    //Popup with information
    onEachFeature: function (feature, layer) {
      return layer.bindPopup("<p><strong>Location: </strong>"
        + feature.properties.place +
        "</p><p><strong>Date & Time: </strong>"
        + new Date(feature.properties.time) +
        "</p><p><strong>Magnitude: </strong>"
        + (feature.properties.mag) + "</p>");
    }
  });
  createMap(earthquakes);
}

// Define circleMarker colors
function circleColor(mag) {
  switch (true) {
    case mag >= 6.0:
      return '#ff0000';
    case mag >= 5.0:
      return '#ff4000';
    case mag >= 4.0:
      return '#ff8000';
    case mag >= 3.0:
      return '#ffbf00';
    case mag >= 2.0:
      return '#ffff00';
    case mag >= 1.0:
      return '#bfff00';
    default:
      return '#80ff00';
  };
};

// Illustrate earthquake magnitude
function circleSize(mag) {
  return mag * 5;
}
//Function to define basemaps
function createMap(earthquakes) {

  var streetmap = L.tileLayer("https://api.tiles.mapbox.com/v4/{id}/{z}/{x}/{y}.png?access_token={accessToken}", {
    attribution: "Map data &copy; <a href=\"https://www.openstreetmap.org/\">OpenStreetMap</a> contributors, <a href=\"https://creativecommons.org/licenses/by-sa/2.0/\">CC-BY-SA</a>, Imagery © <a href=\"https://www.mapbox.com/\">Mapbox</a>",
    maxZoom: 18,
    id: "mapbox.streets",
    accessToken: API_KEY
  });

  var darkmap = L.tileLayer("https://api.tiles.mapbox.com/v4/{id}/{z}/{x}/{y}.png?access_token={accessToken}", {
    attribution: "Map data &copy; <a href=\"https://www.openstreetmap.org/\">OpenStreetMap</a> contributors, <a href=\"https://creativecommons.org/licenses/by-sa/2.0/\">CC-BY-SA</a>, Imagery © <a href=\"https://www.mapbox.com/\">Mapbox</a>",
    maxZoom: 18,
    id: "mapbox.dark",
    accessToken: API_KEY
  });

  // Define baseMaps object
  var baseMaps = {
    "Street Map": streetmap,
    "Dark Map": darkmap
  };

  //Define overlayMaps object
  var overlayMaps = {
    Earthquakes: earthquakes
  };

  //Create map to display when loaded
  var myMap = L.map("map", {
    center: [37.09, -95.71],
    zoom: 4,
    layers: [streetmap, earthquakes]
  });

  //Create layer control with baseMaps and overlapMaps
  L.control.layers(baseMaps, overlayMaps, {
    collapsed: false
  }).addTo(myMap);

  //Create legend for magnitude that corresponds with circle colors
  var legend = L.control({ position: "bottomright" });

  legend.onAdd = function (map) {

    var div = L.DomUtil.create("div", "info legend"),
      labels = ["<strong>Magnitude</strong>"],
      mag = [0, 1, 2, 3, 4, 5, 6];

    for (var i = 0; i < mag.length; i++) {
      div.innerHTML +=
        '<i style="background:' +
        circleColor(mag[i] + 1) + '"></i> ' +
        mag[i] + (mag[i + 1] ? '&ndash;' +
          mag[i + 1] + '<br>' : '+');
    }

    return div;
  };

  legend.addTo(myMap);
};
