// API key
const API_KEY = "pk.eyJ1IjoiYmlsbGV2ZWxvZmYiLCJhIjoiY2p3c2wxcXc4MDNieTQwbnk3NmtnODh1cyJ9.EL_b4DlKrCNuzljXI4MAAg";
