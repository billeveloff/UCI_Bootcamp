# OpenWeatherMap API Key
api_key = "08839b38d172dffe59b338171c369a5a"
