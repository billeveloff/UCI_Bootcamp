// @TODO: YOUR CODE HERE!

//define svg container, margins, and scatterplot area
var width = 960; //960
var height = 500;


var margin = {
    top: 20,
    right: 40,
    bottom: 50,
    left: 40
};

var scatterHeight = height - margin.top - margin.bottom;
var scatterWidth = width - margin.left - margin.right;

//create svg container
var svg = d3.select("#scatter")
    .append("svg")
    .attr("class", "chart")
    .attr("height", height)
    .attr("width", width);

var scatterChart = svg.append("g")
    .attr("transform", `translate(${margin.left}, ${margin.top})`);

// var chosenXAxis = "income";
// var chosenYAxis = "healthcare";

//, function(error, healthData){
    //if (error) throw error;

// //Import data and parse data
// d3.csv("assets/data/data.csv", function(err, healthData) {
//     if (err) throw err;
  
//     // parse data
//     healthData.forEach(function(data) {
//         data.income = +data.income;
//         data.healthcare = +data.healthcare;
//     });


var healthData = d3.csv("assets/data/data.csv")
    .then(function (healthData) {
        healthData.forEach(function (data) {
            data.income = +data.income;
            data.healthcare = +data.healthcare;
            // data.age = +data.age;
            // data.smokes = +data.smokes;
            // data.poverty = +data.poverty;
            // data.obesity = +data.obesity;
});

        var numPadding = 2000;
        //add scale and access functions; append axes
        var xLinearScale = d3.scaleLinear()
            .domain([d3.min(healthData, d => d.income) - numPadding,
            d3.max(healthData, d => d.income) + numPadding])
            .range([0, scatterWidth]);

        var yLinearScale = d3.scaleLinear()
            .domain([d3.min(healthData, d => d.healthcare),
            d3.max(healthData, d => d.healthcare) + 2])
            .range([scatterHeight, 0]);

        var bottomAxis = d3.axisBottom(xLinearScale);
        var leftAxis = d3.axisLeft(yLinearScale);

        scatterChart.append("g")
            .attr("transform", `translate(0, ${scatterHeight})`)
            .attr("class", "chart")
            .call(bottomAxis);

        scatterChart.append("g")
            .call(leftAxis);

        //Add circles
        var circles = scatterChart.selectAll("g")
            .data(healthData)
            .enter()
            .append("circle")
            .attr("cx", d => xLinearScale(d.income))
            .attr("cy", d => yLinearScale(d.healthcare))
            .attr("r", "12")
            .attr("class", "stateCircle")
            .attr("opacity", ".8");
        // .attr("fill", "blue")
        // .attr("stroke-width", "1")
        // .attr("stroke", "black");
        // .html(function (d) {
        //     return (d.abbr)
        // });
        var stateText = scatterChart.selectAll("g")
            // circles
            .data(healthData)
            .enter()
            .append("text")
            .attr("x", d => xLinearScale(d.income))
            .attr("y", d => yLinearScale(d.healthcare) + 5)
            .text(d => (d.abbr))
            .attr("font-size", "10px")
            .attr("text-anchor", "middle")
            .attr("class", "stateText");
        // .text(function(d) {
        //     return d.abbr;
        // });
        // circles.append('text')
        //     .attr('cx',  d => xLinearScale(d.income))
        //     .attr('cy', d => yLinearScale(d.healthcare))
        //     .text(function(d) {
        //         return d.abbr;
        //     });


        //Initialize and create tooltip
        var toolTip = d3.tip()
            .attr("class", "d3-tip")
            .offset([80, -60])
            // .style("display", "block")
            .html(function (d) {
                return (`${d.state}<br>No healthcare: ${d.healthcare}%<br>median HHI: $${d.income}`);
            });

        scatterChart.call(toolTip);

        //Create listeners to show and hide tooltip
        stateText.on("mouseover", function (d) {
            toolTip.show(d, this);
        })
            //onmouseout 
            .on("mouseout", function (d) {
                toolTip.hide(d)
            });

        //Create axes titles
        scatterChart.append("text")
            .attr("transform", "rotate(-90)")
            .attr("y", 0 - margin.left - 3)
            .attr("x", 0 - (height / 2.5))
            .attr("dy", "1em")
            .attr("class", "aText")
            .text("Population % w/o Access to Healthcare");

        scatterChart.append("text")
            .attr("transform", `translate(${width / 2}, ${height + margin.bottom - 80})`)
            .attr("class", "aText")
            .text("Median Household Income (HHI) in USD")
    });


