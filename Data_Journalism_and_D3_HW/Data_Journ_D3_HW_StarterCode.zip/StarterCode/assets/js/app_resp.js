// @TODO: YOUR CODE HERE!
//make the svg responsive to window size
function makeResponsive() {
    //define svg container, margins, and scatterplot area
    var height = 500;
    var width = 750; //960

    var margin = {
        top: 20,
        right: 40,
        bottom: 50,
        left: 40
    };

    var scatterHeight = height - margin.top - margin.bottom;
    var scatterWidth = width - margin.left - margin.right;

    //create svg container
    var svg = d3.select("#scatter")
        .append("svg")
        // .attr("class", "chart")
        .attr("height", height)
        .attr("width", width);

    var scatterChart = svg.append("g")
        .attr("transform", `translate(${margin.left}, ${margin.top})`);

    //Import data and parse data
    d3.csv("assets/data/data.csv")
        .then(function (healthData) {
            healthData.forEach(function (data) {
                data.income = +data.income;
                data.healthcare = +data.healthcare;
            });

            //add scale and access functions; append axes
            var xLinearScale = d3.scaleLinear()
                .domain([20, d3.max(healthData, d => d.income)])
                .range([0, scatterWidth]);

            var yLinearScale = d3.scaleLinear()
                .domain([0, d3.max(healthData, d => d.healthcare)])
                .range([scatterHeight, 0]);

            var bottomAxis = d3.axisBottom(xLinearScale);
            var leftAxis = d3.axisLeft(yLinearScale);

            scatterChart.append("g")
                .attr("transform", `translate(0, ${scatterHeight})`)
                .call(bottomAxis);

            scatterChart.append("g")
                .call(leftAxis);

            //Add circles
            var nodes = scatterChart.selectAll("circle")
                .data(healthData)
                .enter()
                .append("circle")
                .attr("cx", d => xLinearScale(d.income))
                .attr("cy", d => yLinearScale(d.healthcare))
                .attr("r", "10")
                .attr("fill", "blue")
                .attr("opacity", ".5");
            // .attr("stroke-width", "1")
            // .attr("stroke", "black");

            //Initialize and create tooltip
            var toolTip = d3.tip()
                .attr("class", "tooltip")
                .offset([80, -60])
                .html(function (d) {
                    return (`${d.abbr}<br>wo healthcare: ${d.healthcare}<br>median HHI: ${d.income}`);
                });

            scatterChart.call(toolTip);

            //Create listeners to show and hide tooltip
            nodes.on("click", function (data) {
                toolTip.show(data, this);
            })
                //onmouseout 
                .on("mouseout", function (data, index) {
                    toolTip.hide(data)
                });

            //Create axes titles
            scatterChart.append("text")
                .attr("transform", "rotate(-90)")
                .attr("y", 0 - margin.left - 5)
                .attr("x", 0 - (height / 1.5))
                .attr("dy", "1em")
                .attr("class", "axisText")
                .text("Population w/o Access to Healthcare");

            scatterChart.append("text")
                .attr("transform", `translate(${width / 3}, ${height + margin.bottom - 80})`)
                .attr("class", "axisText")
                .text("Median Household Income (HHI)")
        });
// When the browser loads, makeResponsive() is called.
makeResponsive();

// When the browser window is resized, makeResponsive() is called.
d3.select(window).on("resize", makeResponsive)};
