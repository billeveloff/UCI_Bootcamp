#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
from splinter import Browser
from splinter.exceptions import ElementDoesNotExist
from bs4 import BeautifulSoup as bs
import requests
import pymongo

import datetime


# In[2]:


# Set the executable path and initialize the chrome browser in splinter
executable_path = {'executable_path': 'C:\ChromeSafe\chromedriver.exe'}
browser = Browser('chrome', **executable_path)


# In[3]:


#NASA Mars News scraping to save latest News Title and Paragraph Text. 
#Assign text to variables "news_title" and "news_p" for reference later.


# In[4]:


url = "https://mars.nasa.gov/news/"


# In[5]:


browser.visit(url)


# In[6]:


html_1=browser.html
soup_1=bs(html_1, 'html.parser')
# print(html_1)
# print(soup_1.prettify)


# In[7]:


news_article_t=soup_1.select_one("ul.item_list")
# print(news_article_t.prettify)


# In[8]:


news_article_tslide= news_article_t.select_one("li.slide")
# print(news_article_tslide.prettify)


# In[9]:


news_article = soup_1.select_one('ul.item_list li.slide') 
# print(news_article.prettify())


# In[10]:


news_article.find('div', class_='content_title')


# In[11]:


news_article.find('div', class_='content_title').get_text()


# In[12]:


news_title = news_article.find("div", class_='content_title').get_text()
print(news_title)


# In[13]:


news_article.find('div', class_='article_teaser_body').get_text()


# In[14]:


news_p = news_article.find('div', class_='article_teaser_body').get_text()
print(news_p)


# In[15]:


#Visit JPL url to scrape feature image url
#Save full size image to variable called "feature_image_url"


# In[16]:


url_2= "https://www.jpl.nasa.gov/spaceimages/?search=&category=Mars"


# In[17]:


browser.visit(url_2)


# In[18]:


image_small_link=browser.find_link_by_partial_text('FULL IMAGE')
image_small_link.click()


# In[19]:


image_large_link=browser.find_link_by_partial_text('more info')
image_large_link.click()


# In[20]:


html_2=browser.html
soup_2=bs(html_2, 'html.parser')


# In[21]:


feature_image = soup_2.find('figure', class_='lede').a['href']
print(feature_image)


# In[22]:


feature_image_url ='https://www.jpl.nasa.gov' + feature_image
print(feature_image_url)


# In[23]:


#Visit Mars Weather twitter account and scrape latest weather tweet
#Save weather report tweet text  as variable called "mars_weather"


# In[24]:


url_3='https://twitter.com/marswxreport?lang=en'


# In[25]:


browser.visit(url_3)


# In[26]:


html_3=browser.html
soup_3=bs(html_3, 'html.parser')


# In[27]:


mars_weather=soup_3.find('p', class_='TweetTextSize TweetTextSize--normal js-tweet-text tweet-text').text
print(mars_weather)


# In[28]:


#Visit Mars Facts webpage and use Pandas to scrape table with planet facts
#Convert data to a html table string 


# In[29]:


url_4='https://space-facts.com/mars/'


# In[30]:


browser.visit(url_4)


# In[31]:


html_4=browser.html
soup_4=bs(html_4, 'html.parser')


# In[32]:


mars_facts_table = pd.read_html(url_4)
mars_facts_table


# In[33]:


type(mars_facts_table)


# In[34]:


mars_facts_table_df = mars_facts_table[0]
mars_facts_table_df.columns = ['Description', 'Values']
mars_facts_table_df


# In[35]:


mars_facts_table_df.set_index('Description', inplace=True)
mars_facts_table_df


# In[36]:


mars_facts_table_html = mars_facts_table_df.to_html()
mars_facts_table_html


# In[37]:


mars_facts_table_html.replace('\n', '')


# In[38]:


#Visit USGS Astrogeology site to get high resolution images for each Mars' hemisphere.
#Click links to find full resolution images and hemisphere title with name
#Create a python dictionary to store data using keys "img_url" and "title"


# In[39]:


url_5='https://astrogeology.usgs.gov/search/results?q=hemisphere+enhanced&k1=target&v1=Mars'


# In[40]:


browser.visit(url_5)


# In[41]:


html_5=browser.html
soup_5=bs(html_5, 'html.parser')


# In[42]:


all_hemispheres=soup_5.find('div', class_='collapsible results')
# print(all_hemispheres)
hemisphere=all_hemispheres.find_all('div', class_='item')
# print(hemisphere)


# In[43]:


hemisphere_urls=[]

hemisphere_dict={'title':[], 'img_url':[]}

for h in hemisphere:
    title = h.h3.get_text
    browser.find_link_by_partial_text(title)
    img_url = soup_5.find('div', class_='description').a['href']
    hemisphere_dict={'title':[title], 'img_url':[img_url]}
    hemisphere_urls.append(hemisphere_dict)
    browser.visit(url_5)
print(hemisphere_urls) 


# In[44]:


print(url_5)


# In[45]:


browser.visit(url_5)


# In[46]:


# hemisphere_image_urls = []
links = browser.find_by_css("a.product-item h3")


# In[50]:


print(len(links))


# In[55]:


hemisphere_image_urls = []

for i in range(len(links)):
    hemisphere = {}

   # We have to find the elements on each loop to avoid a stale element exception
    browser.find_by_css("a.product-item h3")[i].click()

   # Next, we find the Sample image anchor tag and extract the href
    sample_elem = browser.find_link_by_text('Sample').first
    
    
    hemisphere['img_url'] = sample_elem['href']
#     print(i,hemisphere)

   # Get Hemisphere title
    hemisphere['title'] = browser.find_by_css("h2.title").text
#     print(i,hemisphere)

   # Append hemisphere object to list
    hemisphere_image_urls.append(hemisphere)

   # Finally, we navigate backwards
    browser.back()
print(hemisphere_image_urls)


# In[58]:


hemisphere_image_urls[1]


# In[ ]:


mars_dict=

# mars_return_dict =  {
#        "News_Title": mars_info_dict["Mars_news_title"],
#        "News_Summary" :mars_info_dict["Mars_news_body"],
#        "Featured_Image" : mars_info_dict["Mars_featured_image_url"],
#        "Weather_Tweet" : mars_info_dict["Mars_tweet_weather"],
#        "Facts" : mars_facts_html,
#        "Hemisphere_Image_urls": hemis_img_urls_list,
#        "Date" : mars_info_dict["Date_time"],
#    }


# In[ ]:





# In[127]:


#Use MongoDB with Flask templating to create a new html page 
#that displays all of the information that was scraped from the above urls.


# In[ ]:


#Convert Jupyter notebook into a Python script called scrape_mars.py with a
#function called scrape that will execute all of the scraping code from above.
#Return one Python dictionary containing all of the scraped data.

