#!/usr/bin/env python
# coding: utf-8

# In[14]:


import pandas as pd
from splinter import Browser
from splinter.exceptions import ElementDoesNotExist
from bs4 import BeautifulSoup as bs
import requests
import pymongo

import datetime


# In[15]:


# Set the executable path and initialize the chrome browser in splinter
executable_path = {'executable_path': 'C:\ChromeSafe\chromedriver.exe'}
browser = Browser('chrome', **executable_path)


# In[16]:


#NASA Mars News scraping to save latest News Title and Paragraph Text. 
#Assign text to variables "news_title" and "news_p" for reference later.


# In[17]:


url = "https://mars.nasa.gov/news/"
browser.visit(url)
html_1=browser.html
soup_1=bs(html_1, 'html.parser')


# In[18]:


news_article = soup_1.select_one('ul.item_list li.slide') 
# print(news_article.prettify())


# In[19]:


news_article.find('div', class_='content_title')


# In[20]:


news_article.find('div', class_='content_title').get_text()


# In[21]:


news_title = news_article.find("div", class_='content_title').get_text()
print(news_title)


# In[22]:


news_article.find('div', class_='article_teaser_body').get_text()


# In[23]:


news_p = news_article.find('div', class_='article_teaser_body').get_text()
print(news_p)


# In[24]:


#Visit JPL url to scrape feature image url
#Save full size image to variable called "feature_image_url"


# In[25]:


url_2= "https://www.jpl.nasa.gov/spaceimages/?search=&category=Mars"
browser.visit(url_2)


# In[26]:


image_small_link=browser.find_link_by_partial_text('FULL IMAGE')
image_small_link.click()


# In[27]:


image_large_link=browser.find_link_by_partial_text('more info')
image_large_link.click()


# In[28]:


html_2=browser.html
soup_2=bs(html_2, 'html.parser')


# In[29]:


featured_image = soup_2.find('figure', class_='lede').a['href']
print(featured_image)


# In[30]:


featured_image_url ='https://www.jpl.nasa.gov' + featured_image
print(featured_image_url)


# In[31]:


#Visit Mars Weather twitter account and scrape latest weather tweet
#Save weather report tweet text  as variable called "mars_weather"


# In[32]:


url_3='https://twitter.com/marswxreport?lang=en'


# In[33]:


browser.visit(url_3)
html_3=browser.html
soup_3=bs(html_3, 'html.parser')


# In[34]:


mars_weather=soup_3.find('p', class_='TweetTextSize TweetTextSize--normal js-tweet-text tweet-text').text
print(mars_weather)


# In[35]:


#Visit Mars Facts webpage and use Pandas to scrape table with planet facts
#Convert data to a html table string 


# In[36]:


url_4='https://space-facts.com/mars/'
browser.visit(url_4)
html_4=browser.html
soup_4=bs(html_4, 'html.parser')


# In[37]:


mars_facts_table = pd.read_html(url_4)
mars_facts_table


# In[38]:


type(mars_facts_table)


# In[39]:


mars_facts_table_df = mars_facts_table[0]
mars_facts_table_df.columns = ['Description', 'Values']
mars_facts_table_df


# In[40]:


mars_facts_table_df.set_index('Description', inplace=True)
mars_facts_table_df


# In[41]:


mars_facts_table_html = mars_facts_table_df.to_html()
mars_facts_table_html


# In[42]:


mars_facts_table_html.replace('\n', '')


# In[43]:


#Visit USGS Astrogeology site to get high resolution images for each Mars' hemisphere.
#Click links to find full resolution images and hemisphere title with name
#Create a python dictionary to store data using keys "img_url" and "title"


# In[45]:


url_5='https://astrogeology.usgs.gov/search/results?q=hemisphere+enhanced&k1=target&v1=Mars'
browser.visit(url_5)
html_5=browser.html
soup_5=bs(html_5, 'html.parser')


# In[56]:


hemisphere_links = browser.find_by_css("a.product-item h3")
print(len(hemisphere_links))


# In[49]:


#Create list for dictionary to capture the title and img_url
#for each hemisphere

hemisphere_image_urls = []

for i in range(len(hemisphere_links)):
    hemisphere = {}

    browser.find_by_css("a.product-item h3")[i].click()
    
    sample_image = browser.find_link_by_text('Sample').first
        
    hemisphere['img_url'] = sample_image['href']

    hemisphere['title'] = browser.find_by_css("h2.title").text
    
    hemisphere_image_urls.append(hemisphere)

    browser.back()
print(hemisphere_image_urls)


# In[ ]:





# In[53]:


#create master dictionary with all variables and list
mars_dict = {'latest_news_title': news_title, 
 'latest_news': news_p,
 'featured_image':featured_image_url,
 'latest_weather':mars_weather,
 'mars_facts_table':mars_facts_table_html,
 'hemisphere_images':hemisphere_image_urls 
}
print(mars_dict)


# In[ ]:





# In[127]:


#Use MongoDB with Flask templating to create a new html page 
#that displays all of the information that was scraped from the above urls.


# In[ ]:


#Convert Jupyter notebook into a Python script called scrape_mars.py with a
#function called scrape that will execute all of the scraping code from above.
#Return one Python dictionary containing all of the scraped data.

