#import modules
import os
import csv

#path to file
csvpath = os.path.join("Resources", "budget_data.csv")


#create empty lists to store months and profits
months = []
profits = []
monthly_change_list = []

max_monthly_change = 0
min_monthly_change = 1000000
total_profits = 0
average_change = 0


#open file to read
with open(csvpath, newline="") as csvfile:
    csv_reader = csv.reader(csvfile, delimiter=',')
        
#skip headers
    csv_header = next(csv_reader)
    # print(csv_header)
    first_row = next(csv_reader)
    # print(first_row)
    total_profits = int(first_row[1])
    previous_profit = int(first_row[1])
    # print(total_profits)

#collect data from csv file
    for row in csv_reader:
        current_month = row[0]
        current_profit = int(row[1])
        months.append(current_month)
        profits.append(current_profit)

        #determine total profits over total months
        total_profits += current_profit

        #determine average of profit_loss changes over total months
        monthly_change = current_profit - previous_profit
        monthly_change_list.append(monthly_change)
        # print(monthly_change_list)

#determine total months
total_months = len(months)

#create a monthly_change_list and append month_change

#then calculate the average
average_change = sum(monthly_change_list)/len(monthly_change_list)

#identify month with greatest increase in profits_date and amount

# #indentify month with greatest decrease in profits_date and amount

#print financial analysis
print('Financial Analysis')
print('____________________________')
print('Total Months: ' + str(total_months))
print('Total: $' + str(total_profits))
print('Average Change: $' + str(average_change))
print('Greatest Increase in Profits:')
print('Greatest Decrease in Profits:')

# export financial analysis to text file
# output_files = os.path.join(output.csv)
#     with open(output_files, "w", newline= '') as textfile:
#         write = csv.writer(txtfile)
#         writer.writerow('Financial Analysis')
#         writer.writerow('_____________________________')
#         writer.writerow('Total Months: ' + str(total_months)')
#         writer.writerow('Total: $' + str(total_profits))
#         writer.writerow('Average Change: $' + str(average_change))
#         writer.writerow('Greatest Decrease in Profits:')
#         writer.writerow('Greatest Decrease in Profits:')
