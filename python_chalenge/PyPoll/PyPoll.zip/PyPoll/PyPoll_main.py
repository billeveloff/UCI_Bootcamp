#import modules
import os
import csv

#path to file
csvpath = os.path.join("Resources", "election_data.csv")

#create empty lists to store months and profits
#do we need number of votes by county?

votes = []
candidate_list = []
Khan_votes = []
Correy_votes = []
Li_votes = []
OTooley_votes = []


#open file to read
with open(csvpath, newline="") as csvfile:
    csv_reader = csv.reader(csvfile, delimiter=',')

#skip headers
    csv_header = next(csvfile)

#Report information

#determine total votes cast
    for row in csv_reader:
        votes.append(row[0])
        candidate_list.append(row[2])

    for item

# print(candidate_list)

# Khan_votes = [candidate for candidate in candidate_list if candidate = Khan]

# Khan_votes = candidate_list.count("Khan")
        
        # for candidate in candidate_list:
        #     if candidate = str("Khan"):
        #         Khan_votes.append(candidate)


# for candidate in votes:
    if candidate_list is "Khan":     
        Khan_votes.append

# Khan_votes = [candidate for candidate in votes if candidate is Khan]  
print(Khan_votes)


# july_temperatures = [87, 85, 92, 79, 106]
# hot_days = []
# for temperature in july_temperatures:
#     if temperature > 90:
#         hot_days.append(temperature)
# print(hot_days)

# # List Comprehension with conditional
# hot_days = [temperature for temperature in july_temperatures if temperature > 90]



#determine total number of votes cast for each candidate
total_votes = len(votes)

#determine percentage of votes cast for each candidate


#indentify winner


#print analysis
print('Election Results')
print('____________________________')
print('Total Votes: ' + str(total_votes))
# print('____________________________')
# print('Kahn' + str(xxx))
# print('Correy' + str(xxx))
# print('Li' + str(xxx))
# print("O'Tooley" + str(xxx))
# print('____________________________')
# print("Winner: " )

#export election results to text file
output_files = os.path.join(output.csv)
    with open(output_files, "w", newline= '') as textfile:
        write = csv.writer(textfile)
        writer.writerow('Election Results')
        writer.writerow('_____________________________')
        writer.writerow('Total Votes: ' + str(total_votes))
#         writer.writerow('_____________________________')
#         writer.writerow('Kahn' + str(xxx))
#         writer.writerow('Correy' + str(xxx))
#         writer.writerow('Li' + str(xxx))
#         writer.writerow("O'Tooley" + str(xxx))
#         writer.writerow('_____________________________')
#         writer.writerow("Winner: ")