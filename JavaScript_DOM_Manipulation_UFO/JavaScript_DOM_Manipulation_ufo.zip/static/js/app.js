// from data.js and view data 
var tableData = data;
console.log("tableData", tableData)

// variable that utilizes d3 to reference table body in html
var tbody = d3.select("tbody");

//function to clear existing data, loop thru data objects,
//append rows, and add values to the tds in tbody. 
function createTable(data) {
console.log(createTable)
  tbody.html("");

  data.forEach((dataRow) => {
    
    var row = tbody.append("tr");

    Object.entries(dataRow).forEach(([key,value]) => {
      // console.log(key, value); 
      var cell = row.append("td");
        cell.text(value);
      }
    );
  });
};

//function to prevent page refresh, filter data based on query,
//and update table with rows with associated data (datetime)
function handleClick() {
  d3.event.preventDefault();
  var dateInput = d3.select("#datetime").property("value");
  console.log(dateInput)
  var filterData = tableData

   filterData = filterData.filter(row => row.datetime === dateInput);
   console.log("filterData", filterData)

   createTable(filterData)
}
// create event listener in form
d3.selectAll("#filter-btn").on("click", handleClick);

createTable(tableData);