# OpenWeatherMap API Key
api_key = "cb8ddc857212fb723d5556beaccd7f04"
